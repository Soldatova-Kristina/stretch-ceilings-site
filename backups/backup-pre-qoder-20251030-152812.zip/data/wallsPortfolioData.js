export const wallsPortfolioData = {
  images: [
    '/images/walls/our3.jpg',
    '/images/walls/our4.jpg',
    '/images/walls/our1.jpg',
    '/images/walls/ou2.jpg',
  ],
  address: 'Примеры работ - Тихие стены'
};
