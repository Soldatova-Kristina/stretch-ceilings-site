export const COMPANY_PHONE = '+79320076085';
export const COMPANY_PHONE_DISPLAY = '+79320076085';
export const TELEGRAM_URL = 'https://t.me/piterpotolok';
export const WHATSAPP_URL = 'https://wa.me/+79679786000';
export const VK_URL = 'https://vk.com/piterpoto1ok';